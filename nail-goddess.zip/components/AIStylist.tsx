import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Sparkles, Wand2, Loader2 } from 'lucide-react';

export const AIStylist: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleConsultation = async () => {
    if (!prompt.trim()) return;
    
    setLoading(true);
    setSuggestion(null);

    try {
      const apiKey = process.env.API_KEY || '';
      if (!apiKey) {
        setSuggestion("AI features are currently unavailable. Please try again later.");
        setLoading(false);
        return;
      }

      const ai = new GoogleGenAI({ apiKey });
      const model = 'gemini-2.5-flash';
      
      const systemInstruction = `You are a high-end, trendy celebrity nail artist. 
      The user will tell you an occasion, outfit, or mood.
      Your goal is to suggest a specific nail design, color palette, and vibe.
      Keep it short, punchy, and exciting (max 3 sentences). 
      Include emojis. 
      End with a specific recommendation like "Try a chrome powder" or "Go for a matte top coat".`;

      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          systemInstruction,
        }
      });

      setSuggestion(response.text || "Could not generate a style. Try again!");

    } catch (error) {
      console.error("AI Error", error);
      setSuggestion("Oops! My creative spark is offline. Check back soon.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-4 my-10 p-6 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 rounded-3xl text-white shadow-2xl relative overflow-hidden">
      {/* Decorative Circles */}
      <div className="absolute -top-10 -right-10 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
      <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>

      <div className="relative z-10">
        <div className="flex items-center gap-2 mb-4">
          <Wand2 className="w-6 h-6 text-yellow-300" />
          <h2 className="text-2xl font-bold">AI Nail Stylist</h2>
        </div>
        
        <p className="mb-6 text-white/90">
          Going to a party? Need a seasonal look? Tell me your vibe, and I'll design your next set!
        </p>

        <div className="space-y-4">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="e.g. I'm wearing a red dress to a winter wedding..."
            className="w-full p-4 rounded-2xl bg-white/20 backdrop-blur-md placeholder-white/60 text-white border border-white/30 focus:outline-none focus:border-white focus:bg-white/30 transition-all resize-none h-24"
          />

          <button
            onClick={handleConsultation}
            disabled={loading || !prompt}
            className="w-full py-4 bg-white text-purple-600 font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-purple-50 transition-all disabled:opacity-50 active:scale-95"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                Style Me
              </>
            )}
          </button>

          {suggestion && (
            <div className="mt-6 p-4 bg-white/90 backdrop-blur-sm rounded-2xl text-purple-900 animate-fade-in shadow-lg">
              <h3 className="font-bold mb-2 flex items-center gap-2">
                <span className="text-xl">💅</span> Your Look:
              </h3>
              <p className="leading-relaxed font-medium">{suggestion}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};