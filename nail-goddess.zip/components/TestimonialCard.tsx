import React from 'react';
import { Testimonial } from '../types';
import { Quote } from 'lucide-react';

export const TestimonialCard: React.FC<{ testimonial: Testimonial }> = ({ testimonial }) => {
  return (
    <div className="bg-white p-6 rounded-2xl shadow-md min-w-[280px] snap-center border border-pink-50">
      <Quote className="w-8 h-8 text-pink-200 mb-4" />
      <p className="text-gray-600 mb-6 italic">"{testimonial.text}"</p>
      <div className="flex items-center gap-3">
        <img 
            src={testimonial.avatar} 
            alt={testimonial.name}
            className="w-10 h-10 rounded-full border-2 border-pink-200" 
        />
        <div>
            <h4 className="font-bold text-gray-800 text-sm">{testimonial.name}</h4>
            <div className="flex gap-0.5">
                {[...Array(testimonial.rating)].map((_, i) => (
                    <span key={i} className="text-yellow-400 text-xs">★</span>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};