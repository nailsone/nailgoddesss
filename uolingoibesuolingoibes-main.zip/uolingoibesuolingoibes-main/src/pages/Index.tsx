import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Sparkles, Zap, Clock, Download, Star, Home, Mail, Menu, Check } from "lucide-react";
import logo from "@/assets/logo.jpg";
import heroCover from "@/assets/hero-cover.jpg";
const Index = () => {
  const [email, setEmail] = useState("");
  const products = [{
    title: "Spanish Quick Start Guide",
    description: "Master essential phrases in just 7 days",
    image: "📚",
    badge: "Bestseller"
  }, {
    title: "French Grammar Cheat Sheet",
    description: "All tenses on one simple PDF",
    image: "🇫🇷",
    badge: "Popular"
  }, {
    title: "Japanese Hiragana Mastery",
    description: "Learn to read in 2 weeks",
    image: "🇯🇵",
    badge: "New"
  }, {
    title: "German Vocabulary Bundle",
    description: "1000+ words with pronunciation",
    image: "🇩🇪",
    badge: "Bundle"
  }, {
    title: "Italian Conversation Pack",
    description: "Real-world dialogues for travelers",
    image: "🇮🇹",
    badge: "Popular"
  }, {
    title: "Duolingo Study Planner",
    description: "Track your progress & stay motivated",
    image: "📅",
    badge: "Essential"
  }];
  const testimonials = [{
    name: "Sarah M.",
    text: "These guides helped me ace my Spanish test! So much easier than textbooks.",
    rating: 5
  }, {
    name: "Mike L.",
    text: "Perfect companion to Duolingo. My streak is at 180 days now!",
    rating: 5
  }, {
    name: "Emma K.",
    text: "Love how everything is mobile-friendly. I learn on my commute every day.",
    rating: 5
  }];
  const features = [{
    icon: <Zap className="w-6 h-6" />,
    text: "Quick-learning PDF guides"
  }, {
    icon: <BookOpen className="w-6 h-6" />,
    text: "Duolingo-friendly structure"
  }, {
    icon: <Clock className="w-6 h-6" />,
    text: "Easy to read on your phone"
  }, {
    icon: <Download className="w-6 h-6" />,
    text: "Instant downloads"
  }, {
    icon: <Sparkles className="w-6 h-6" />,
    text: "Boost your streak learning"
  }];
  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({
      behavior: 'smooth'
    });
  };
  return <div className="min-h-screen bg-background pb-20">
      {/* Hero Section */}
      <section className="relative h-[70vh] flex items-center justify-center text-center overflow-hidden" style={{
      backgroundImage: `url(${heroCover})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center'
    }}>
        <div className="absolute inset-0 bg-gradient-to-b from-primary/60 via-primary/40 to-background/95" />
        <div className="relative z-10 px-6 space-y-6 animate-slide-up">
          <img src={logo} alt="DuolingoVibes Logo" className="w-24 h-24 mx-auto rounded-full shadow-lg border-4 border-white animate-float" />
          <h1 className="text-4xl md:text-5xl font-black text-white leading-tight">
            Learn Languages Faster<br />with DuolingoVibes
          </h1>
          <p className="text-lg text-white/90 max-w-md mx-auto font-semibold">
            Download Smart Language Guides & Boost Your Learning Today
          </p>
          <Button onClick={() => scrollToSection('products')} size="lg" className="bg-white text-primary hover:bg-white/90 font-bold text-lg px-8 py-6 rounded-full shadow-lg hover:scale-105 transition-all">
            Explore Guides <Sparkles className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* About Section */}
      <section className="px-6 py-12 max-w-2xl mx-auto">
        <div className="text-center space-y-4">
          
          <h2 className="text-3xl font-black text-primary">About DuolingoVibes</h2>
          <p className="text-lg text-foreground/80 leading-relaxed">
            We create fun, friendly digital tools to help language learners like you improve faster. 
            Our guides work perfectly alongside your Duolingo lessons, making learning feel like play!
          </p>
        </div>
      </section>

      {/* Featured Products */}
      <section id="products" className="px-6 py-12 bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-black text-primary text-center mb-8">
            Featured Digital Products
          </h2>
          <div className="grid grid-cols-1 gap-6">
            {products.map((product, index) => <Card key={index} className="overflow-hidden border-2 border-border hover:border-primary transition-all hover:shadow-lg hover:-translate-y-1" style={{
            animationDelay: `${index * 100}ms`
          }}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="text-5xl flex-shrink-0">{product.image}</div>
                    <div className="flex-1 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-bold text-lg text-foreground">{product.title}</h3>
                        <Badge className="bg-accent text-accent-foreground shrink-0">
                          {product.badge}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{product.description}</p>
                      <Button className="w-full mt-3 bg-primary hover:bg-primary/90 text-primary-foreground font-bold rounded-full">
                        Get This Guide <Download className="ml-2 w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>)}
          </div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section className="px-6 py-12">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl font-black text-primary text-center mb-8">
            Why Choose DuolingoVibes?
          </h2>
          <div className="space-y-4">
            {features.map((feature, index) => <div key={index} className="flex items-center gap-4 bg-card p-4 rounded-2xl border-2 border-border hover:border-primary transition-all">
                <div className="bg-primary/10 p-3 rounded-full text-primary">
                  {feature.icon}
                </div>
                <p className="font-semibold text-foreground">{feature.text}</p>
              </div>)}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="px-6 py-12 bg-muted/30">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl font-black text-primary text-center mb-8">
            What Learners Say
          </h2>
          <div className="space-y-4">
            {testimonials.map((testimonial, index) => <Card key={index} className="border-2 border-border">
                <CardContent className="p-6 space-y-2">
                  <div className="flex gap-1">
                    {[...Array(testimonial.rating)].map((_, i) => <Star key={i} className="w-4 h-4 fill-primary text-primary" />)}
                  </div>
                  <p className="text-foreground/80 italic">"{testimonial.text}"</p>
                  <p className="font-bold text-primary">— {testimonial.name}</p>
                </CardContent>
              </Card>)}
          </div>
        </div>
      </section>

      {/* Email Capture */}
      <section className="px-6 py-12">
        <div className="max-w-md mx-auto">
          <Card className="border-2 border-primary bg-gradient-to-br from-primary/5 to-accent/5">
            <CardContent className="p-8 space-y-4 text-center">
              <Mail className="w-12 h-12 mx-auto text-primary" />
              <h2 className="text-2xl font-black text-primary">
                Get Free Mini Guides Weekly
              </h2>
              <p className="text-foreground/70">
                Join 10,000+ language learners getting exclusive tips & resources
              </p>
              <div className="flex flex-col gap-3">
                <Input type="email" placeholder="Enter your email" value={email} onChange={e => setEmail(e.target.value)} className="rounded-full border-2 border-input focus:border-primary" />
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold rounded-full">
                  Subscribe Now <Check className="ml-2 w-4 h-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                No spam. Unsubscribe anytime.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-8 border-t-2 border-border bg-muted/20">
        <div className="max-w-2xl mx-auto text-center space-y-4">
          
          <p className="text-sm text-muted-foreground">
            Not affiliated with Duolingo.
          </p>
          <p className="text-sm font-semibold text-foreground">
            © 2025 DuolingoVibes. All rights reserved.
          </p>
        </div>
      </footer>

      {/* Sticky Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t-2 border-border shadow-lg z-50">
        <div className="flex justify-around items-center py-3 px-6 max-w-lg mx-auto">
          <button onClick={() => window.scrollTo({
          top: 0,
          behavior: 'smooth'
        })} className="flex flex-col items-center gap-1 text-primary hover:scale-110 transition-transform">
            <Home className="w-6 h-6" />
            <span className="text-xs font-semibold">Home</span>
          </button>
          <button onClick={() => scrollToSection('products')} className="flex flex-col items-center gap-1 text-primary hover:scale-110 transition-transform">
            <BookOpen className="w-6 h-6" />
            <span className="text-xs font-semibold">Guides</span>
          </button>
          <button onClick={() => scrollToSection('products')} className="flex flex-col items-center gap-1 text-primary hover:scale-110 transition-transform">
            <Mail className="w-6 h-6" />
            <span className="text-xs font-semibold">Contact</span>
          </button>
        </div>
      </nav>
    </div>;
};
export default Index;