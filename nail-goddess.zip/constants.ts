import { Product, Testimonial } from './types';

export const HERO_IMAGE = "https://images.unsplash.com/photo-1604654894610-df63bc536371?auto=format&fit=crop&q=80&w=800";

export const PRODUCTS: Product[] = [
  {
    id: '1',
    title: 'Pro Gel UV Kit',
    description: 'Complete salon-quality gel manicure kit with 48W LED Lamp and 6 popular shades.',
    price: '$45.99',
    image: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?auto=format&fit=crop&q=80&w=500',
    category: 'tools',
    affiliateLink: 'https://example.com/affiliate/gel-kit',
    rating: 5
  },
  {
    id: '2',
    title: 'Holographic Chrome Powder',
    description: 'Create stunning mirror-effect nails. Easy to apply on top of any gel polish.',
    price: '$12.50',
    image: 'https://images.unsplash.com/photo-1632515904033-6447d956557d?auto=format&fit=crop&q=80&w=500',
    category: 'art',
    affiliateLink: 'https://example.com/affiliate/chrome-powder',
    rating: 4.5
  },
  {
    id: '3',
    title: 'Cuticle Revival Oil',
    description: 'Vitamin E infused oil to keep your cuticles healthy and hydrated. A must-have!',
    price: '$8.99',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=500',
    category: 'care',
    affiliateLink: 'https://example.com/affiliate/oil',
    rating: 5
  },
  {
    id: '4',
    title: 'Pastel Dream Set',
    description: '6 pack of long-lasting, chip-resistant pastel nail polishes for spring vibes.',
    price: '$22.00',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdd403348?auto=format&fit=crop&q=80&w=500',
    category: 'polish',
    affiliateLink: 'https://example.com/affiliate/pastels',
    rating: 4
  },
  {
    id: '5',
    title: 'Professional E-File Drill',
    description: 'Portable electric nail drill for shaping, buffing, and removing gel quickly.',
    price: '$35.00',
    image: 'https://images.unsplash.com/photo-1599693766620-1b5fb36c1c87?auto=format&fit=crop&q=80&w=500',
    category: 'tools',
    affiliateLink: 'https://example.com/affiliate/drill',
    rating: 4.8
  },
  {
    id: '6',
    title: 'Crystal Rhinestone Pack',
    description: '1000+ pieces of multi-sized rhinestones to add sparkle to any design.',
    price: '$9.99',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&q=80&w=500',
    category: 'art',
    affiliateLink: 'https://example.com/affiliate/gems',
    rating: 4.2
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    name: 'Sarah M.',
    avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026024d',
    text: 'The gel kit recommended here saved me so much money compared to the salon!',
    rating: 5
  },
  {
    id: 't2',
    name: 'Jessica K.',
    avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026704d',
    text: 'Loved the AI suggestions! It helped me pick the perfect color for my graduation.',
    rating: 5
  },
  {
    id: 't3',
    name: 'Emily R.',
    avatar: 'https://i.pravatar.cc/150?u=a04258114e29026302d',
    text: 'Fast links, great products. The cuticle oil is a game changer.',
    rating: 4
  }
];
