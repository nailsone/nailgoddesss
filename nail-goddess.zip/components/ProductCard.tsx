import React from 'react';
import { Product } from '../types';
import { ExternalLink, Star } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden flex flex-col h-full transform transition-all hover:-translate-y-1 hover:shadow-xl">
      <div className="relative h-48">
        <img 
          src={product.image} 
          alt={product.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded-lg flex items-center gap-1 shadow-sm">
          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
          <span className="text-xs font-bold text-gray-700">{product.rating}</span>
        </div>
      </div>
      
      <div className="p-5 flex flex-col flex-grow">
        <div className="mb-2">
            <span className="text-[10px] font-bold tracking-wider uppercase text-pink-500 bg-pink-50 px-2 py-1 rounded-md">
                {product.category}
            </span>
        </div>
        <h3 className="text-lg font-bold text-gray-800 mb-1 leading-tight">{product.title}</h3>
        <p className="text-gray-500 text-sm mb-4 line-clamp-2">{product.description}</p>
        
        <div className="mt-auto flex items-center justify-between gap-3">
          <span className="font-bold text-xl text-gray-900">{product.price}</span>
          <a 
            href={product.affiliateLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 bg-gray-900 text-white py-2.5 px-4 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 hover:bg-gray-800 transition-colors active:scale-95"
          >
            Get It <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
};