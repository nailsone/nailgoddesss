import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";
import { 
  Sparkles, 
  Menu, 
  ArrowRight, 
  Wand2, 
  Loader2, 
  ExternalLink, 
  Star, 
  Quote, 
  Instagram, 
  Facebook, 
  Twitter, 
  Heart,
  Tag,
  Zap,
  Gift,
  ShoppingBag
} from 'lucide-react';

// --- TYPES ---
interface Product {
  id: string;
  title: string;
  description: string;
  price: string;
  image: string;
  category: 'polish' | 'tools' | 'art' | 'care';
  affiliateLink: string;
  rating: number;
}

interface Testimonial {
  id: string;
  name: string;
  avatar: string;
  text: string;
  rating: number;
}

// --- CONSTANTS ---
const BRAND_NAME = "Nail Goddess";
const LOGO_URL = "https://i.pinimg.com/280x280_RS/73/78/72/737872dc23335915ed9356cf5dd52533.jpg";
const HERO_IMAGE = "https://images.unsplash.com/photo-1519014816548-bf5fe059e98b?auto=format&fit=crop&q=80&w=800"; // Elegant hands

const PRODUCTS: Product[] = [
  {
    id: '1',
    title: 'Luxury Gel UV Kit',
    description: 'Salon-quality gel manicure kit with 48W LED Lamp and 6 popular nude & blush shades.',
    price: '$45.99',
    image: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?auto=format&fit=crop&q=80&w=500',
    category: 'tools',
    affiliateLink: '#', // Replace with your link
    rating: 5
  },
  {
    id: '2',
    title: 'Holographic Chrome Powder',
    description: 'Create stunning mirror-effect nails. Easy to apply on top of any gel polish.',
    price: '$12.50',
    image: 'https://images.unsplash.com/photo-1632515904033-6447d956557d?auto=format&fit=crop&q=80&w=500',
    category: 'art',
    affiliateLink: '#',
    rating: 4.5
  },
  {
    id: '3',
    title: 'Gold Flake Cuticle Oil',
    description: '24k gold infused oil to keep your cuticles healthy, hydrated, and glowing.',
    price: '$18.99',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=500',
    category: 'care',
    affiliateLink: '#',
    rating: 5
  },
  {
    id: '4',
    title: 'Velvet Matte Top Coat',
    description: 'Transform any glossy polish into a sophisticated cashmere-touch matte finish.',
    price: '$14.00',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdd403348?auto=format&fit=crop&q=80&w=500',
    category: 'polish',
    affiliateLink: '#',
    rating: 4
  },
  {
    id: '5',
    title: 'Pro E-File Drill',
    description: 'Portable electric nail drill for shaping, buffing, and removing gel quickly.',
    price: '$35.00',
    image: 'https://images.unsplash.com/photo-1599693766620-1b5fb36c1c87?auto=format&fit=crop&q=80&w=500',
    category: 'tools',
    affiliateLink: '#',
    rating: 4.8
  },
  {
    id: '6',
    title: 'Swarovski Crystal Pack',
    description: 'Genuine crystals to add that ultimate luxury sparkle to your designs.',
    price: '$29.99',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&q=80&w=500',
    category: 'art',
    affiliateLink: '#',
    rating: 4.9
  }
];

const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    name: 'Sarah M.',
    avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026024d',
    text: 'The gel kit recommended here saved me so much money compared to the salon!',
    rating: 5
  },
  {
    id: 't2',
    name: 'Jessica K.',
    avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026704d',
    text: 'Loved the AI suggestions! It helped me pick the perfect color for my graduation.',
    rating: 5
  },
  {
    id: 't3',
    name: 'Emily R.',
    avatar: 'https://i.pravatar.cc/150?u=a04258114e29026302d',
    text: 'Nail Goddess always finds the best niche products. Love it.',
    rating: 4
  }
];

// --- COMPONENTS ---

const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-pink-100 shadow-sm">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img 
            src={LOGO_URL} 
            alt={BRAND_NAME} 
            className="w-10 h-10 rounded-full border-2 border-pink-200 object-cover shadow-sm"
          />
          <span className="font-serif font-bold text-xl text-gray-800 tracking-tight">{BRAND_NAME}</span>
        </div>
        <button className="p-2 hover:bg-pink-50 rounded-full transition-colors">
          <Menu className="w-6 h-6 text-gray-600" />
        </button>
      </div>
    </header>
  );
};

const Hero: React.FC = () => {
  return (
    <div className="relative w-full h-[520px] overflow-hidden rounded-b-[40px] shadow-2xl">
      <img 
        src={HERO_IMAGE} 
        alt="Beautiful Nail Art" 
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-gray-900/90 via-gray-900/40 to-transparent flex flex-col justify-end p-8 pb-16">
        <div className="animate-fade-in-up">
          <span className="inline-block px-4 py-1.5 bg-pink-500/90 backdrop-blur-sm text-white text-xs font-bold rounded-full mb-4 uppercase tracking-widest">
            Affiliate Exclusive
          </span>
          <h1 className="font-serif text-5xl font-medium text-white mb-3 leading-tight">
            Divine Nails,<br/>
            <span className="text-pink-300 italic">Every Day.</span>
          </h1>
          <p className="text-gray-200 mb-8 text-lg font-light">
            Curated collections of the world's finest nail art supplies and tools.
          </p>
          <a 
            href="#products"
            className="inline-flex items-center gap-2 bg-white text-gray-900 px-8 py-4 rounded-full font-bold text-lg hover:bg-pink-50 transition-colors shadow-xl active:scale-95 transform duration-150"
          >
            Shop Trends <ArrowRight className="w-5 h-5" />
          </a>
        </div>
      </div>
    </div>
  );
};

const AIStylist: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleConsultation = async () => {
    if (!prompt.trim()) return;
    
    setLoading(true);
    setSuggestion(null);

    try {
      const apiKey = process.env.API_KEY || '';
      if (!apiKey) {
        setSuggestion("AI Stylist is currently resting. Please try again later.");
        setLoading(false);
        return;
      }

      const ai = new GoogleGenAI({ apiKey });
      const model = 'gemini-2.5-flash';
      
      const systemInstruction = `You are a luxury nail stylist for 'Nail Goddess'. 
      The user will tell you an occasion or mood.
      Suggest a sophisticated, trendy nail design.
      Keep it short, elegant, and inspiring (max 40 words). 
      Include 1-2 emojis.`;

      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: { systemInstruction }
      });

      setSuggestion(response.text || "Could not generate a style. Try again!");

    } catch (error) {
      console.error("AI Error", error);
      setSuggestion("My creative spirit is offline momentarily.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-4 my-12 p-1 bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-400 rounded-[32px] shadow-2xl">
      <div className="bg-gray-900 rounded-[30px] p-6 relative overflow-hidden">
        {/* Abstract Background */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-pink-500/20 rounded-full blur-3xl -mr-16 -mt-16"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/20 rounded-full blur-3xl -ml-16 -mb-16"></div>

        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <Wand2 className="w-5 h-5 text-pink-300" />
            <span className="text-pink-300 font-bold tracking-wider text-xs uppercase">AI Stylist</span>
          </div>
          <h2 className="font-serif text-3xl font-medium text-white mb-4">Find Your Vibe</h2>
          
          <p className="mb-6 text-gray-400 text-sm">
            Describe your outfit or mood, and let the Goddess design your manicure.
          </p>

          <div className="space-y-4">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. I need something elegant for a black-tie gala..."
              className="w-full p-4 rounded-2xl bg-white/10 backdrop-blur-md placeholder-gray-500 text-white border border-white/10 focus:outline-none focus:border-pink-500/50 focus:bg-white/15 transition-all resize-none h-24 text-base"
            />

            <button
              onClick={handleConsultation}
              disabled={loading || !prompt}
              className="w-full py-4 bg-gradient-to-r from-pink-500 to-purple-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50 active:scale-95 shadow-lg shadow-purple-900/50"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Reveal My Look
                </>
              )}
            </button>

            {suggestion && (
              <div className="mt-6 p-5 bg-white/10 border border-white/10 backdrop-blur-md rounded-2xl text-pink-100 animate-fade-in">
                <p className="leading-relaxed font-serif italic text-lg">"{suggestion}"</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const ProductCard: React.FC<{ product: Product }> = ({ product }) => {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-pink-50 overflow-hidden flex flex-col h-full transform transition-all hover:shadow-xl">
      <div className="relative h-64 overflow-hidden">
        <img 
          src={product.image} 
          alt={product.title} 
          className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-700"
        />
        <div className="absolute top-3 right-3 bg-white/95 backdrop-blur px-2 py-1 rounded-md flex items-center gap-1 shadow-sm">
          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
          <span className="text-xs font-bold text-gray-800">{product.rating}</span>
        </div>
        {product.price.includes('$') && (
            <div className="absolute bottom-3 left-3 bg-black/70 backdrop-blur text-white px-3 py-1 rounded-full text-xs font-bold">
                {product.price}
            </div>
        )}
      </div>
      
      <div className="p-5 flex flex-col flex-grow">
        <div className="mb-2">
            <span className="text-[10px] font-bold tracking-wider uppercase text-pink-600 bg-pink-50 px-2 py-1 rounded-md">
                {product.category}
            </span>
        </div>
        <h3 className="font-serif text-xl text-gray-900 mb-2 leading-tight">{product.title}</h3>
        <p className="text-gray-500 text-sm mb-6 line-clamp-2 font-light">{product.description}</p>
        
        <div className="mt-auto">
          <a 
            href={product.affiliateLink}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full bg-gray-900 text-white py-3.5 px-4 rounded-xl text-sm font-bold flex items-center justify-center gap-2 hover:bg-gray-800 transition-colors active:scale-95 shadow-lg shadow-gray-200"
          >
            Get It Now <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
};

const TestimonialCard: React.FC<{ testimonial: Testimonial }> = ({ testimonial }) => {
  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm min-w-[300px] snap-center border border-gray-100 relative">
      <Quote className="absolute top-6 right-6 w-8 h-8 text-pink-100" />
      <div className="flex items-center gap-3 mb-4">
        <img 
            src={testimonial.avatar} 
            alt={testimonial.name}
            className="w-12 h-12 rounded-full border border-gray-100 object-cover" 
        />
        <div>
            <h4 className="font-serif font-bold text-gray-900">{testimonial.name}</h4>
            <div className="flex gap-0.5">
                {[...Array(testimonial.rating)].map((_, i) => (
                    <span key={i} className="text-yellow-400 text-xs">★</span>
                ))}
            </div>
        </div>
      </div>
      <p className="text-gray-600 italic font-light leading-relaxed">"{testimonial.text}"</p>
    </div>
  );
};

const Footer: React.FC = () => {
  return (
    <footer className="bg-white pt-16 pb-32 rounded-t-[50px] mt-12 shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.1)]">
      <div className="max-w-md mx-auto px-8 text-center">
        <div className="flex justify-center mb-6">
            <img src={LOGO_URL} alt="Logo" className="w-16 h-16 rounded-full border-4 border-pink-50 shadow-inner" />
        </div>
        <h2 className="font-serif text-3xl font-bold mb-4 text-gray-900">{BRAND_NAME}</h2>
        <p className="text-gray-500 mb-8 font-light leading-relaxed">
          Curating the most beautiful, niche nail products for the modern goddess.
        </p>

        <div className="flex justify-center gap-6 mb-10">
          <a href="#" className="p-3 bg-pink-50 text-pink-600 rounded-full hover:bg-pink-100 transition-colors">
            <Instagram className="w-5 h-5" />
          </a>
          <a href="#" className="p-3 bg-pink-50 text-pink-600 rounded-full hover:bg-pink-100 transition-colors">
            <Facebook className="w-5 h-5" />
          </a>
          <a href="#" className="p-3 bg-pink-50 text-pink-600 rounded-full hover:bg-pink-100 transition-colors">
            <Twitter className="w-5 h-5" />
          </a>
        </div>

        <div className="border-t border-gray-100 pt-8">
          <p className="text-xs text-gray-400 mb-4 leading-relaxed">
            Disclaimer: {BRAND_NAME} is a participant in affiliate programs. We earn commissions from qualifying purchases made through our links.
          </p>
          <div className="flex items-center justify-center gap-1 text-xs text-gray-400">
            <span>Designed with</span>
            <Heart className="w-3 h-3 text-pink-400 fill-pink-400" />
            <span>for nail enthusiasts</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- APP ---

const App: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const filteredProducts = activeCategory === 'all' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === activeCategory);

  const categories = [
    { id: 'all', label: 'All' },
    { id: 'polish', label: 'Polish' },
    { id: 'tools', label: 'Tools' },
    { id: 'art', label: 'Art' },
  ];

  return (
    <div className="min-h-screen pb-safe bg-[#FDF2F8]">
      <Header />
      
      <main className="max-w-md mx-auto bg-white min-h-screen shadow-2xl overflow-hidden relative">
        <Hero />

        {/* Benefits Strip */}
        <div className="flex justify-between px-8 py-10 bg-white relative z-10 -mt-8 rounded-t-[40px] shadow-[0_-10px_20px_-5px_rgba(0,0,0,0.05)]">
            <div className="flex flex-col items-center gap-3 text-center">
                <div className="bg-pink-50 p-3 rounded-2xl text-pink-500">
                    <Zap className="w-6 h-6" />
                </div>
                <span className="text-xs font-bold text-gray-600 uppercase tracking-wide">Fast<br/>Shipping</span>
            </div>
            <div className="flex flex-col items-center gap-3 text-center">
                <div className="bg-purple-50 p-3 rounded-2xl text-purple-500">
                    <Tag className="w-6 h-6" />
                </div>
                <span className="text-xs font-bold text-gray-600 uppercase tracking-wide">Best<br/>Deals</span>
            </div>
            <div className="flex flex-col items-center gap-3 text-center">
                <div className="bg-blue-50 p-3 rounded-2xl text-blue-500">
                    <Gift className="w-6 h-6" />
                </div>
                <span className="text-xs font-bold text-gray-600 uppercase tracking-wide">Pro<br/>Tips</span>
            </div>
        </div>

        {/* AI Section */}
        <AIStylist />

        {/* Products Section */}
        <section id="products" className="px-5 py-8">
          <div className="flex items-end justify-between mb-8 px-1">
            <div>
                <h2 className="font-serif text-3xl font-medium text-gray-900">Curated Finds</h2>
                <div className="h-1 w-12 bg-pink-500 mt-2 rounded-full"></div>
            </div>
            <span className="text-sm text-gray-400 font-medium mb-1">{filteredProducts.length} items</span>
          </div>

          {/* Category Filter */}
          <div className="flex gap-3 overflow-x-auto pb-6 hide-scrollbar pl-1">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-6 py-2.5 rounded-full text-sm font-bold whitespace-nowrap transition-all border ${
                  activeCategory === cat.id 
                    ? 'bg-gray-900 text-white border-gray-900 shadow-lg' 
                    : 'bg-white text-gray-500 border-gray-200 hover:bg-gray-50'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 gap-8">
            {filteredProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>

        {/* Newsletter Section */}
        <section className="mx-4 my-12 p-8 bg-pink-100 rounded-[32px] text-center relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/40 rounded-full blur-2xl -mr-10 -mt-10"></div>
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/40 rounded-full blur-2xl -ml-10 -mb-10"></div>
            
            <div className="relative z-10">
                <h3 className="font-serif text-2xl font-bold text-gray-900 mb-3">Join the Inner Circle</h3>
                <p className="text-gray-600 mb-6 font-light">Get exclusive discounts and trendy nail art tutorials sent to your inbox.</p>
                <div className="flex flex-col gap-3">
                    <input 
                        type="email" 
                        placeholder="Enter your email" 
                        className="w-full px-4 py-3.5 rounded-xl bg-white border border-pink-200 text-gray-900 focus:border-pink-500 focus:outline-none placeholder-gray-400 shadow-sm"
                    />
                    <button className="w-full py-3.5 bg-pink-500 text-white font-bold rounded-xl hover:bg-pink-600 transition-colors shadow-lg shadow-pink-200">
                        Subscribe Free
                    </button>
                </div>
            </div>
        </section>

        {/* Testimonials */}
        <section className="py-12 bg-gray-50 mb-8 border-y border-gray-100">
            <h2 className="font-serif text-2xl font-bold text-gray-900 px-6 mb-8 text-center">Goddess Reviews</h2>
            <div className="flex overflow-x-auto px-6 gap-5 pb-8 hide-scrollbar snap-x">
                {TESTIMONIALS.map(t => (
                    <TestimonialCard key={t.id} testimonial={t} />
                ))}
            </div>
        </section>

        <Footer />
        
        {/* Sticky Mobile Nav Bottom */}
        <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-gray-900/95 backdrop-blur-xl border border-gray-800 shadow-2xl rounded-full px-8 py-4 flex items-center gap-10 z-50">
            <button className="flex flex-col items-center text-pink-400 transform scale-105">
                <ShoppingBag className="w-5 h-5 mb-1" />
                <span className="text-[10px] font-bold tracking-wide">SHOP</span>
            </button>
            <button className="flex flex-col items-center text-gray-400 hover:text-white transition-colors">
                <Sparkles className="w-5 h-5 mb-1" />
                <span className="text-[10px] font-bold tracking-wide">AI</span>
            </button>
            <button className="flex flex-col items-center text-gray-400 hover:text-white transition-colors">
                <Heart className="w-5 h-5 mb-1" />
                <span className="text-[10px] font-bold tracking-wide">FAVES</span>
            </button>
        </div>

      </main>
    </div>
  );
};

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);