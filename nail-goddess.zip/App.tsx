import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ProductCard } from './components/ProductCard';
import { AIStylist } from './components/AIStylist';
import { TestimonialCard } from './components/TestimonialCard';
import { Footer } from './components/Footer';
import { PRODUCTS, TESTIMONIALS } from './constants';
import { Tag, Zap, Gift } from 'lucide-react';

const App: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const filteredProducts = activeCategory === 'all' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === activeCategory);

  const categories = [
    { id: 'all', label: 'All' },
    { id: 'polish', label: 'Polish' },
    { id: 'tools', label: 'Tools' },
    { id: 'art', label: 'Art' },
  ];

  return (
    <div className="min-h-screen pb-safe">
      <Header />
      
      <main className="max-w-md mx-auto bg-gray-50 min-h-screen shadow-2xl overflow-hidden relative">
        <Hero />

        {/* Benefits Strip */}
        <div className="flex justify-between px-6 py-8 bg-white -mt-6 relative z-10 rounded-t-[30px] shadow-sm">
            <div className="flex flex-col items-center gap-2 text-center">
                <div className="bg-pink-100 p-3 rounded-full text-pink-600">
                    <Zap className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold text-gray-600 uppercase tracking-wide">Fast<br/>Results</span>
            </div>
            <div className="flex flex-col items-center gap-2 text-center">
                <div className="bg-purple-100 p-3 rounded-full text-purple-600">
                    <Tag className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold text-gray-600 uppercase tracking-wide">Best<br/>Prices</span>
            </div>
            <div className="flex flex-col items-center gap-2 text-center">
                <div className="bg-blue-100 p-3 rounded-full text-blue-600">
                    <Gift className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold text-gray-600 uppercase tracking-wide">Pro<br/>Tips</span>
            </div>
        </div>

        {/* AI Section */}
        <AIStylist />

        {/* Products Section */}
        <section id="products" className="px-4 py-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800">Top Picks</h2>
            <span className="text-sm text-pink-500 font-semibold">{filteredProducts.length} items</span>
          </div>

          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-4 hide-scrollbar mb-4">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-5 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-all ${
                  activeCategory === cat.id 
                    ? 'bg-pink-500 text-white shadow-lg shadow-pink-200' 
                    : 'bg-white text-gray-500 border border-gray-100 hover:bg-gray-50'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 gap-6">
            {filteredProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>

        {/* Newsletter Section */}
        <section className="mx-4 my-8 p-8 bg-gray-900 rounded-3xl text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500"></div>
            <h3 className="text-2xl font-bold text-white mb-2">Join the Club</h3>
            <p className="text-gray-400 mb-6 text-sm">Get exclusive discounts and trendy nail art tutorials sent to your inbox.</p>
            <div className="flex flex-col gap-3">
                <input 
                    type="email" 
                    placeholder="Enter your email" 
                    className="w-full px-4 py-3 rounded-xl bg-gray-800 border border-gray-700 text-white focus:border-pink-500 focus:outline-none placeholder-gray-500"
                />
                <button className="w-full py-3 bg-pink-500 text-white font-bold rounded-xl hover:bg-pink-600 transition-colors">
                    Subscribe Free
                </button>
            </div>
        </section>

        {/* Testimonials */}
        <section className="py-8 bg-pink-50/50 mb-8">
            <h2 className="text-2xl font-bold text-gray-800 px-6 mb-6">Community Love</h2>
            <div className="flex overflow-x-auto px-6 gap-4 pb-8 hide-scrollbar snap-x">
                {TESTIMONIALS.map(t => (
                    <TestimonialCard key={t.id} testimonial={t} />
                ))}
            </div>
        </section>

        <Footer />
        
        {/* Sticky Mobile Nav Bottom */}
        <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-white/90 backdrop-blur-xl border border-gray-200 shadow-2xl rounded-full px-6 py-3 flex items-center gap-8 z-50">
            <button className="flex flex-col items-center text-pink-500">
                <div className="w-1 h-1 bg-pink-500 rounded-full mb-1"></div>
                <span className="text-xs font-bold">Shop</span>
            </button>
            <button className="flex flex-col items-center text-gray-400 hover:text-gray-600">
                <span className="text-xs font-bold">Trends</span>
            </button>
            <button className="flex flex-col items-center text-gray-400 hover:text-gray-600">
                <span className="text-xs font-bold">Guide</span>
            </button>
        </div>

      </main>
    </div>
  );
};

export default App;