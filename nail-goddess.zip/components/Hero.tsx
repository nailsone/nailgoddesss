import React from 'react';
import { HERO_IMAGE } from '../constants';
import { ArrowRight } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <div className="relative w-full h-[500px] overflow-hidden rounded-b-[40px] shadow-xl">
      <img 
        src={HERO_IMAGE} 
        alt="Beautiful Nail Art" 
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent flex flex-col justify-end p-8 pb-12">
        <div className="animate-fade-in-up">
          <span className="inline-block px-3 py-1 bg-pink-500 text-white text-xs font-bold rounded-full mb-3 uppercase tracking-wider">
            Trending Now
          </span>
          <h1 className="text-4xl font-bold text-white mb-2 leading-tight">
            Salon Quality,<br/>
            <span className="text-pink-300">At Home.</span>
          </h1>
          <p className="text-gray-200 mb-6 text-lg">
            Discover the best tools & trends for your next manicure.
          </p>
          <a 
            href="#products"
            className="inline-flex items-center gap-2 bg-white text-pink-600 px-6 py-3 rounded-full font-bold text-lg hover:bg-pink-50 transition-colors shadow-lg active:scale-95 transform duration-150"
          >
            Shop The Look <ArrowRight className="w-5 h-5" />
          </a>
        </div>
      </div>
    </div>
  );
};