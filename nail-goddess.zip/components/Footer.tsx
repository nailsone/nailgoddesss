import React from 'react';
import { Instagram, Facebook, Twitter, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white pt-12 pb-24 rounded-t-[40px] mt-12">
      <div className="max-w-md mx-auto px-6 text-center">
        <h2 className="text-2xl font-bold mb-4">LuxeNail Vibes</h2>
        <p className="text-gray-400 mb-8 text-sm">
          Your daily dose of nail inspiration and professional product recommendations.
        </p>

        <div className="flex justify-center gap-6 mb-8">
          <a href="#" className="p-3 bg-gray-800 rounded-full hover:bg-gray-700 transition-colors">
            <Instagram className="w-5 h-5" />
          </a>
          <a href="#" className="p-3 bg-gray-800 rounded-full hover:bg-gray-700 transition-colors">
            <Facebook className="w-5 h-5" />
          </a>
          <a href="#" className="p-3 bg-gray-800 rounded-full hover:bg-gray-700 transition-colors">
            <Twitter className="w-5 h-5" />
          </a>
        </div>

        <div className="border-t border-gray-800 pt-8">
          <p className="text-xs text-gray-500 mb-4">
            Disclaimer: LuxeNail Vibes participates in various affiliate marketing programs, which means we may get paid commissions on editorially chosen products purchased through our links to retailer sites.
          </p>
          <div className="flex items-center justify-center gap-1 text-sm text-gray-400">
            <span>Made with</span>
            <Heart className="w-4 h-4 text-pink-500 fill-pink-500" />
            <span>for nail lovers</span>
          </div>
        </div>
      </div>
    </footer>
  );
};