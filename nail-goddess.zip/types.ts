export interface Product {
  id: string;
  title: string;
  description: string;
  price: string;
  image: string;
  category: 'polish' | 'tools' | 'art' | 'care';
  affiliateLink: string;
  rating: number;
}

export interface Testimonial {
  id: string;
  name: string;
  avatar: string;
  text: string;
  rating: number;
}
