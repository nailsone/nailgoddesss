import React from 'react';
import { Sparkles, Menu } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-pink-100 shadow-sm">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="bg-pink-500 p-1.5 rounded-xl">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-xl text-gray-800 tracking-tight">LuxeNail</span>
        </div>
        <button className="p-2 hover:bg-pink-50 rounded-full transition-colors">
          <Menu className="w-6 h-6 text-gray-600" />
        </button>
      </div>
    </header>
  );
};